import { useCallback, useEffect, useState } from 'react'
import { Alert, Button, Card, Form, Input, InputNumber, Modal, Popconfirm, Space, Table, Typography, message } from 'antd'
import type { ColumnsType } from 'antd/es/table'
import { ReloadOutlined, UserOutlined } from '@ant-design/icons'
import { api, fetchPage, getErrorMessage, type PageResult } from '../lib/api'
import { useAuth } from '../context/AuthContext'

interface Student { id: number; user: number; name: string; student_no: string; age: number }
interface Teacher { id: number; user: number; name: string; department: string }
type Person = Student | Teacher

export default function PeoplePage({ kind }: { kind: 'students' | 'teachers' }) {
  const { user } = useAuth()
  const isStudentList = kind === 'students'
  const role = user?.profile?.type
  const canEdit = role === 'admin' || (!isStudentList && role === 'teacher')
  const [page, setPage] = useState(1)
  const [data, setData] = useState<PageResult<Person>>({ results: [], count: 0, next: null, previous: null })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [editing, setEditing] = useState<Person | null>(null)
  const [open, setOpen] = useState(false)
  const [form] = Form.useForm()

  const load = useCallback(async () => {
    setLoading(true); setError('')
    try { setData(await fetchPage<Person>(`/${kind}/`, { page })) }
    catch (e) { setError(getErrorMessage(e)) }
    finally { setLoading(false) }
  }, [kind, page])
  useEffect(() => { void load() }, [load])

  const save = async (values: Record<string, unknown>) => {
    if (!editing) return
    try {
      await api.patch(`/${kind}/${editing.id}/`, values)
      message.success('资料已更新'); setOpen(false); await load()
    } catch (e) { message.error(getErrorMessage(e)) }
  }
  const remove = async (id: number) => {
    try { await api.delete(`/${kind}/${id}/`); message.success('资料已删除'); await load() }
    catch (e) { message.error(getErrorMessage(e)) }
  }

  const columns: ColumnsType<Person> = isStudentList ? [
    { title: '学生', dataIndex: 'name', render: (v: string, r) => <div className="person-cell"><span className="person-avatar student"><UserOutlined /></span><span><strong>{v}</strong><small>资料 ID #{r.id}</small></span></div> },
    { title: '学号', dataIndex: 'student_no' },
    { title: '年龄', dataIndex: 'age', width: 100, render: (v: number) => `${v} 岁` },
    { title: '关联用户 ID', dataIndex: 'user', width: 130 },
    { title: '操作', key: 'action', width: 150, render: (_, record) => <Space>{role === 'admin' && <Button type="link" onClick={() => { setEditing(record); form.setFieldsValue(record); setOpen(true) }}>编辑</Button>}{role === 'admin' && <Popconfirm title="确定删除该学生资料？" onConfirm={() => remove(record.id)}><Button type="link" danger>删除</Button></Popconfirm>}</Space> },
  ] : [
    { title: '教师', dataIndex: 'name', render: (v: string, r) => <div className="person-cell"><span className="person-avatar teacher"><UserOutlined /></span><span><strong>{v}</strong><small>资料 ID #{r.id}</small></span></div> },
    { title: '所属院系', dataIndex: 'department', render: (v: string) => v || '未填写' },
    { title: '关联用户 ID', dataIndex: 'user', width: 130 },
    { title: '操作', key: 'action', width: 150, render: (_, record) => <Space>{(role === 'admin' || (role === 'teacher' && record.user === user?.id)) && <Button type="link" onClick={() => { setEditing(record); form.setFieldsValue(record); setOpen(true) }}>编辑</Button>}{role === 'admin' && <Popconfirm title="确定删除该教师资料？" description="有关联课程时，删除可能被数据库保护。" onConfirm={() => remove(record.id)}><Button type="link" danger>删除</Button></Popconfirm>}</Space> },
  ]

  return <>
    <div className="page-heading"><div><Typography.Title level={2}>{isStudentList ? '学生管理' : '教师管理'}</Typography.Title><Typography.Paragraph>{isStudentList ? '查看学生基本资料及其账号关联。' : '查看教师基本资料及所属院系。'}</Typography.Paragraph></div></div>
    {error && <Alert type="error" showIcon message={error} className="mb-16" />}
    <Card bordered={false} className="table-card">
      <div className="table-toolbar"><span className="muted">资料列表</span><Button icon={<ReloadOutlined />} onClick={() => void load()}>刷新</Button></div>
      <Table rowKey="id" columns={columns} dataSource={data.results} loading={loading} scroll={{ x: 650 }} pagination={{ current: page, pageSize: 20, total: data.count, showSizeChanger: false, onChange: setPage, showTotal: (total) => `共 ${total} 条资料` }} />
    </Card>
    <Modal title={`编辑${isStudentList ? '学生' : '教师'}资料`} open={open} onCancel={() => setOpen(false)} onOk={() => form.submit()} okText="保存" cancelText="取消" destroyOnClose>
      <Form form={form} layout="vertical" onFinish={save}>
        <Form.Item name="name" label="姓名" rules={[{ required: true, whitespace: true, message: '请输入姓名' }]}><Input maxLength={50} /></Form.Item>
        {isStudentList ? <>
          <Form.Item name="student_no" label="学号" rules={[{ required: true, message: '请输入学号' }]}><Input maxLength={50} /></Form.Item>
          <Form.Item name="age" label="年龄" rules={[{ required: true, type: 'number', min: 1 }]}><InputNumber min={1} style={{ width: '100%' }} /></Form.Item>
        </> : <Form.Item name="department" label="所属院系"><Input maxLength={100} /></Form.Item>}
      </Form>
    </Modal>
    {!canEdit && <Alert type="info" message="当前账号仅有查看权限。" className="mt-16" />}
  </>
}
