def main() -> None:
    print("Hello from course-management!")
